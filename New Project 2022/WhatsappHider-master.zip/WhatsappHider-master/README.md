# WhatsappHider
An android app to hide last seen time stamp in Whatsapp
