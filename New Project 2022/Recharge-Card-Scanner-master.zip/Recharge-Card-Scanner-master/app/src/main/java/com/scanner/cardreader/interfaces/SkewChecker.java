package com.scanner.cardreader.interfaces;

import android.graphics.Bitmap;

/**
 * Created by Anush Shrestha on 8/3/2016.
 */

public interface SkewChecker {
    double getSkewAngle(Bitmap sourceBitmap);
}
