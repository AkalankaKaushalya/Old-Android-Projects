package com.scanner.cardreader.interfaces;

import android.graphics.Bitmap;

/**
 * Created by anush on 7/4/2016.
 */
public interface Threshold {
    Bitmap threshold(Bitmap sourceBitmap);
 }
