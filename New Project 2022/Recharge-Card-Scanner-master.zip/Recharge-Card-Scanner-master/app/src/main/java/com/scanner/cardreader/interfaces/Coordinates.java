package com.scanner.cardreader.interfaces;

import android.graphics.Rect;

/**
 * Created by aviisekh on 8/20/16.
 */
public interface Coordinates {
    public Rect getCoordinates();
}
