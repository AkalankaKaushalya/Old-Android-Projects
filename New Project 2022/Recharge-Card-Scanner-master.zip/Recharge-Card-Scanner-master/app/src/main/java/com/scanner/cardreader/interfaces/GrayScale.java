package com.scanner.cardreader.interfaces;

import android.graphics.Bitmap;

/**
 * Created by anush on 7/5/2016.
 */

public interface GrayScale {
   Bitmap grayScale();
}
