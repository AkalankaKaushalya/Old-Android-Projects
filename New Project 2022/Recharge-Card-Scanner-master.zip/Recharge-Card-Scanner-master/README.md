#RCardScanner

An android app to scan the image of recharge card and grab the pin number to top up the balance.
