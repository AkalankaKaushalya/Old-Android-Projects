from processImage import generateBinaryData, scaleImage, cropImage
generateBinaryData()
print "\nTraining sets updated"