package top.defaults.colorpicker;

class Constants {

    static final int EVENT_MIN_INTERVAL = 1000 / 60; // 16ms

    static final int SELECTOR_RADIUS_DP = 9;
}
