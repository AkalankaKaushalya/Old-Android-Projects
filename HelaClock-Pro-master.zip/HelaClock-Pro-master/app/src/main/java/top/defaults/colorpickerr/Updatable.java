package top.defaults.colorpickerr;

import android.view.MotionEvent;

public interface Updatable {

    void update(MotionEvent event);
}
