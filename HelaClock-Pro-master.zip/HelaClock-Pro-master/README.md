# HelaClock-Pro

[![license](https://img.shields.io/github/license/DAVFoundation/captain-n3m0.svg?style=flat-square)](https://github.com/00sanoj00/HelaClock-Pro/blob/master/LICENSE)

###### @SaNoJ :+1: Simple Sinhala TextClock Widget  - it's ready :shipit:

#### [Download](https://github.com/00sanoj00/HelaClock-Pro/releases/)

![alt text](https://github.com/00sanoj00/HelaClock-Pro/blob/master/Image/Screenshot%20from%202019-09-20%2020-32-34.png?raw=true)![alt text](https://github.com/00sanoj00/HelaClock-Pro/blob/master/Image/Screenshot%20from%202019-09-15%2023-56-25.png?raw=true)

![alt text](https://github.com/00sanoj00/HelaClock-Pro/blob/master/Image/Screenshot%20from%202019-09-15%2023-59-06.png?raw=true)![alt text](https://github.com/00sanoj00/HelaClock-Pro/blob/master/Image/Screenshot%20from%202019-09-15%2023-59-49.png?raw=true)

![alt text](https://github.com/00sanoj00/HelaClock-Pro/blob/master/Image/Screenshot%20from%202019-09-20%2020-48-11.png?raw=true)![alt text](hhttps://github.com/00sanoj00/HelaClock-Pro/blob/master/Image/Screenshot%20from%202019-09-20%2021-00-43.png?raw=true)






