# TextConverter
Android app to do text conversion for instance hex to ASCII string, clean space, clean to upper case, to lower case etc.

Requirements:

1. Android Studio 3.x
2. Android SDK >= 19
