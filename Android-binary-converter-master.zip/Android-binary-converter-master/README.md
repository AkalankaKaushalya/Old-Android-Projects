# Android-binary-converter

android app to convert and reconvert binary code
very simple, no professional code
