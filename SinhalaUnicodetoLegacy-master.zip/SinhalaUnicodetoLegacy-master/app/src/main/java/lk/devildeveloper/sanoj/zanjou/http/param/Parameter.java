package lk.devildeveloper.sanoj.zanjou.http.param;

/**
 * Created by ander on 9/12/17.
 */

public interface Parameter {

    String getKey();
    Object getValue();
}
