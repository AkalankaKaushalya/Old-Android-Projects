package net.simplifiedcoding.wallpaperhub.models;

/**
 * Created by Belal on 4/21/2018.
 */

public class Category {
    public String name, desc, thumb;

    public Category(String name, String desc, String thumb) {
        this.name = name;
        this.desc = desc;
        this.thumb = thumb;
    }
}
