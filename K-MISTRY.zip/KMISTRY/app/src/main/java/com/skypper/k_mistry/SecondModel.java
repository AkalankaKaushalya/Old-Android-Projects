package com.skypper.k_mistry;

public class SecondModel {
    String name,year,surl;

    SecondModel() {

    }

    public SecondModel(String name, String year, String surl) {
        this.name = name;
        this.year = year;
        this.surl = surl;
    }

    public String getName() {
        return name;
    }

    public String getYear() {
        return year;
    }

    public String getSurl() {
        return surl;
    }
}
