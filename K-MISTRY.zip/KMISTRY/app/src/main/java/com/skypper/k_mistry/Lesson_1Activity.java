package com.skypper.k_mistry;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class Lesson_1Activity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_lesson1);
    }
}