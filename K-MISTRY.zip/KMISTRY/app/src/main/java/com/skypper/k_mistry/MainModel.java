package com.skypper.k_mistry;

public class MainModel {
    String name, email, surl, course, details_1, details_2, details_3, details_4, details_5, details_6, details_7, details_8, details_9, details__10, details__11, details__12, details__13, details__14, details__15, details__16, details__17, details__18, details__19, details__20;

    MainModel() {

    }

    public MainModel(String name, String email, String surl, String course, String details_1, String details_2, String details_3, String details_4, String details_5, String details_6, String details_7, String details_8, String details_9, String details__10, String details__11, String details__12, String details__13, String details__14, String details__15, String details__16, String details__17, String details__18, String details__19, String details__20) {
        this.name = name;
        this.email = email;
        this.surl = surl;
        this.course = course;
        this.details_1 = details_1;
        this.details_2 = details_2;
        this.details_3 = details_3;
        this.details_4 = details_4;
        this.details_5 = details_5;
        this.details_6 = details_6;
        this.details_7 = details_7;
        this.details_8 = details_8;
        this.details_9 = details_9;
        this.details__10 = details__10;
        this.details__11 = details__11;
        this.details__12 = details__12;
        this.details__13 = details__13;
        this.details__14 = details__14;
        this.details__15 = details__15;
        this.details__16 = details__16;
        this.details__17 = details__17;
        this.details__18 = details__18;
        this.details__19 = details__19;
        this.details__20 = details__20;
    }

    public String getName() {
        return name;
    }

    public String getEmail() {
        return email;
    }

    public String getSurl() {
        return surl;
    }

    public String getCourse() {
        return course;
    }

    public String getDetails_1() {
        return details_1;
    }

    public String getDetails_2() {
        return details_2;
    }

    public String getDetails_3() {
        return details_3;
    }

    public String getDetails_4() {
        return details_4;
    }

    public String getDetails_5() {
        return details_5;
    }

    public String getDetails_6() {
        return details_6;
    }

    public String getDetails_7() {
        return details_7;
    }

    public String getDetails_8() {
        return details_8;
    }

    public String getDetails_9() {
        return details_9;
    }

    public String getDetails__10() {
        return details__10;
    }

    public String getDetails__11() {
        return details__11;
    }

    public String getDetails__12() {
        return details__12;
    }

    public String getDetails__13() {
        return details__13;
    }

    public String getDetails__14() {
        return details__14;
    }

    public String getDetails__15() {
        return details__15;
    }

    public String getDetails__16() {
        return details__16;
    }

    public String getDetails__17() {
        return details__17;
    }

    public String getDetails__18() {
        return details__18;
    }

    public String getDetails__19() {
        return details__19;
    }

    public String getDetails__20() {
        return details__20;
    }
}