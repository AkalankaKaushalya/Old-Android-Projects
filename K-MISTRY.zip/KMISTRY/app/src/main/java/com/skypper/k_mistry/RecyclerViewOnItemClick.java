package com.skypper.k_mistry;

public interface RecyclerViewOnItemClick {
    void  onItemClck(int position);
}
