# I don't collect any information.

1. Camera permission for barcode reader
2. Write external storage for share image.