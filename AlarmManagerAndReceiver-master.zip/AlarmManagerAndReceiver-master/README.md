# AlarmManagerAndReceiver
Alarm Manager to set an alarm which calls a receiver, and receiver generates a notification

[![Twitter Follow](https://img.shields.io/twitter/follow/Ajit5ingh.svg?style=social)](https://twitter.com/Ajit5ingh)
[![HitCount](http://hits.dwyl.io/ajitsing/AlarmManagerAndReceiver.svg)](http://hits.dwyl.io/ajitsing/AlarmManagerAndReceiver)

## Watch this video to understand scheduling local notification in depth
[![IMAGE ALT TEXT](http://img.youtube.com/vi/k-tREnlQsrk/0.jpg)](https://www.youtube.com/watch?v=k-tREnlQsrk "Demo")
