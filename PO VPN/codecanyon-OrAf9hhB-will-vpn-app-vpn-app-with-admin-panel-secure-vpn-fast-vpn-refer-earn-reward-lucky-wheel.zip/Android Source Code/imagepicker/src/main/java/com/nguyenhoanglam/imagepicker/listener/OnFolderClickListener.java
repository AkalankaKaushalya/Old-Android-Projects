package com.nguyenhoanglam.imagepicker.listener;

import com.nguyenhoanglam.imagepicker.model.Folder;


public interface OnFolderClickListener {
    void onFolderClick(Folder folder);
}
