package com.nguyenhoanglam.imagepicker.ui.common;



public interface MvpView {
}
