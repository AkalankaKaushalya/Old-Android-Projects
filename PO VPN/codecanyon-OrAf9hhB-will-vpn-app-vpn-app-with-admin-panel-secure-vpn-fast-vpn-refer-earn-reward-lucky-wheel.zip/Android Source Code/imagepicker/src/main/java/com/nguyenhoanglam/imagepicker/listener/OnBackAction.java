package com.nguyenhoanglam.imagepicker.listener;


public interface OnBackAction {
    void onBackToFolder();

    void onFinishImagePicker();
}
