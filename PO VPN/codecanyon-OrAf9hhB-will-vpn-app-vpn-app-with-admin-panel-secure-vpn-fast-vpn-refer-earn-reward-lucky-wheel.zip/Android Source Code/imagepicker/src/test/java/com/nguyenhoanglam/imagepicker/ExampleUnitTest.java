package com.nguyenhoanglam.imagepicker;

import org.junit.Test;

import static org.junit.Assert.assertEquals;


public class ExampleUnitTest {
    @Test
    public void addition_isCorrect() throws Exception {
        assertEquals(4, 2 + 2);
    }
}