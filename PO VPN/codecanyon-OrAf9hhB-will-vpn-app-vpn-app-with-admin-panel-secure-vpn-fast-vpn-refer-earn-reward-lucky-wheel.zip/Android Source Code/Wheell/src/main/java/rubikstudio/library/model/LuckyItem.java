package rubikstudio.library.model;



public class LuckyItem {
    public String text;
    public int icon;
    public int color;
}
