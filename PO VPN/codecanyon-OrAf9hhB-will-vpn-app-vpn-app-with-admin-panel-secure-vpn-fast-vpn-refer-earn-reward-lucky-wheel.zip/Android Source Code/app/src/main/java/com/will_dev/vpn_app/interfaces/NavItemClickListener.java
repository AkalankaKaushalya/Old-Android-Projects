package com.will_dev.vpn_app.interfaces;

public interface NavItemClickListener {
    void clickedItem(int index);
}
