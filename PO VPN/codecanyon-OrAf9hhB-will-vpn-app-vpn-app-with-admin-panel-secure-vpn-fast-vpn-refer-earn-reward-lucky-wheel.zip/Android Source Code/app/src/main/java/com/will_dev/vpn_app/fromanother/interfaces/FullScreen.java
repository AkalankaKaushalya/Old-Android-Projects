package com.will_dev.vpn_app.fromanother.interfaces;

public interface FullScreen {

    void fullscreen(boolean isFull);

}
