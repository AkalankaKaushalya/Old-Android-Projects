package com.will_dev.vpn_app.interfaces;

import com.will_dev.vpn_app.model.Server;

public interface ChangeServer {
    void newServer(Server server);
}
