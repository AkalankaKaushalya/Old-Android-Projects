package com.will_dev.vpn_app.api;

public class WebAPI {
    public static String ADMIN_PANEL_API = "https://project.willdev.in/WILL_VPN/";
    public static String FREE_SERVERS = "";
    public static String PREMIUM_SERVERS = "";
    public static String ADMOB_BANNER = "";
    public static String ADMOB_INTERSTITIAL = "";
    public static String ADMOB_ID = "";
    public static String ADMOB_NATIVE = "";
    public static String ADMOB_REWARD_ID = "";
    public static String ADS_TYPE = "";

    public static String ADS_TYPE_ADMOB = "ADMOB";
    public static String ADS_TYPE_FACEBOOK_ADS = "FACEBOOK_ADS";
}
