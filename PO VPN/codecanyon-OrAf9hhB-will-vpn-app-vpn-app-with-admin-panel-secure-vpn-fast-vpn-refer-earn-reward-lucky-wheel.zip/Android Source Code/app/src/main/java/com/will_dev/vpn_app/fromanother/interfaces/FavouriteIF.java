package com.will_dev.vpn_app.fromanother.interfaces;

public interface FavouriteIF {

    void isFavourite(String isFavourite,String message);

}
