package com.will_dev.vpn_app.fromanother.interfaces;

public interface VideoAd {

    void videoAdClick(String type);

}
