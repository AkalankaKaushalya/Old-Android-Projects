package com.will_dev.vpn_app.utils;

public class Config {

    public static final String IAP_LISENCE_KEY = "";



    public static final String all_month_id = "g1";
    public static final String all_threemonths_id = "g2";
    public static final String all_sixmonths_id = "g3";
    public static final String all_yearly_id = "g4";


    public static boolean vip_subscription = false;
    public static boolean all_subscription = false;
}
