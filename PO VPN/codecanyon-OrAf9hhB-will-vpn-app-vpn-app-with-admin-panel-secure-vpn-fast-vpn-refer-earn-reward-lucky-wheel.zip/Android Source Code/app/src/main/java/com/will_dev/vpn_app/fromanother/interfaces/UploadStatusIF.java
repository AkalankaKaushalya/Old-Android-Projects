package com.will_dev.vpn_app.fromanother.interfaces;

public interface UploadStatusIF {

    void UploadType(String type);

}
