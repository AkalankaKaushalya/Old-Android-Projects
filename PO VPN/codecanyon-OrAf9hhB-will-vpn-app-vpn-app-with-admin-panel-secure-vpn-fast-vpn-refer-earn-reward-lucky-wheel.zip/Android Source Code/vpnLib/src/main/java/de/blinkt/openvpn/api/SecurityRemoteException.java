

package de.blinkt.openvpn.api;

import android.os.RemoteException;

public class SecurityRemoteException extends RemoteException {


	private static final long serialVersionUID = 1L;

}
