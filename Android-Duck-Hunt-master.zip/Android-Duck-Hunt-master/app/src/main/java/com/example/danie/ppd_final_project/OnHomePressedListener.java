package com.example.danie.ppd_final_project;

/**
 * Created by daniel on 12/19/17.
 */

public interface OnHomePressedListener {
    void onHomePressed();
}